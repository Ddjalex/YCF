const target = new Date("2026-03-01T00:00:00").getTime();

function update(id,val){
  const el=document.getElementById(id);
  const v=String(val).padStart(2,'0');
  if(el.textContent!==v){
    el.textContent=v;
    el.classList.remove('animate');
    void el.offsetWidth;
    el.classList.add('animate');
  }
}

setInterval(()=>{
  const now=new Date().getTime();
  const d=target-now;

  const days=Math.floor(d/(1000*60*60*24));
  const hours=Math.floor((d%(1000*60*60*24))/(1000*60*60));
  const minutes=Math.floor((d%(1000*60*60))/(1000*60));
  const seconds=Math.floor((d%(1000*60))/1000);

  update("days",days);
  update("hours",hours);
  update("minutes",minutes);
  update("seconds",seconds);
},1000);
